# Ambiente de desenvolvimento:

    Windows 11 com WSL2 rodando Ubuntu 22.04.2 LTS
    Python 3.10.6

# Instruções de execução:

    Para executar o programa, cujo nome é simplex.py, basta utilizar o seguinte comando:

        python3 simplex.py [arquivo_de_entrada].txt [arquivo_de_saida].txt
    
    Ambos os arquivos devem ser passados como argumento para a correta execução do programa